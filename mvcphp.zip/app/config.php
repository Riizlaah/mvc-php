<?php
  //File Konfigurasi
  //Url web
  define('BASEURL', 'https://nrweb.eu.org/');
  
  //db info
  define('HOST', 'localhost');
  define('DB_USER', 'root');
  define('DB_PASS', 'root');
  define('DB_NAME', 'heker');
  
  
?>