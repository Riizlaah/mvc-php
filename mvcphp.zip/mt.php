<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Maintenance</title>
    <style>
      body {
        padding: 15px;
      }
      .hek {
        margin-top: 100px;
        box-sizing: border-box;
        width: 100%;
        padding: 11px;
        background-color: rgba(235,69,69,0.611);
        border-radius: 5px;
      }
    </style>
  </head>
  <body>
    <div class="hek">
      <h1>Server dalam perbaikan :)</h1>
    </div>
  </body>
</html>