<?php
  //File Konfigurasi
  //Url web
  define('BASEURL', 'https://websitemu.com/');
  
  //db info (MySQL)
  define('HOST', 'localhost'); //DB host 
  define('DB_USER', 'root'); //DB username
  define('DB_PASS', 'root'); //DB Password
  define('DB_NAME', 'heker'); // nama Database
  
  
?>