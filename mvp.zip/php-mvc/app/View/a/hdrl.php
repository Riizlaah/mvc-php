<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests; object-src 'none'">
  <title><?= $data['jud']; ?></title>
  <script src="https://kit.fontawesome.com/3260cb9060.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="<?= BASEURL; ?>aset/i.css">
</head>