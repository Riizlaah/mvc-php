<?php
  
  require_once 'app/Inti/inti.php';
  require_once 'config.php';
  
  
?>